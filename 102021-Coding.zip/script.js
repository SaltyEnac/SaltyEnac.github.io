function submit(){
  var hello = document.getElementById('select')
  window.alert(hello)
}